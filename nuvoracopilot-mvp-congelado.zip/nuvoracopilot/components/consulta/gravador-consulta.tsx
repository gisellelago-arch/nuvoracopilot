"use client";

import { useEffect, useRef, useState } from "react";
import { Play, Pause, Square } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { salvarObservacoes, finalizarConsultaAction } from "@/lib/actions/consulta.actions";

interface GravadorConsultaProps {
  consultaId: string;
  observacoesIniciais: string;
}

function formatarTempo(totalSegundos: number) {
  const minutos = Math.floor(totalSegundos / 60)
    .toString()
    .padStart(2, "0");
  const segundos = (totalSegundos % 60).toString().padStart(2, "0");
  return `${minutos}:${segundos}`;
}

export function GravadorConsulta({ consultaId, observacoesIniciais }: GravadorConsultaProps) {
  const [segundos, setSegundos] = useState(0);
  const [gravando, setGravando] = useState(false);
  const intervaloRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    if (gravando) {
      intervaloRef.current = setInterval(() => setSegundos((s) => s + 1), 1000);
    } else if (intervaloRef.current) {
      clearInterval(intervaloRef.current);
    }
    return () => {
      if (intervaloRef.current) clearInterval(intervaloRef.current);
    };
  }, [gravando]);

  const salvarObservacoesComId = salvarObservacoes.bind(null, consultaId);
  const finalizarComId = finalizarConsultaAction.bind(null, consultaId);

  return (
    <div className="space-y-6">
      <div className="flex flex-col items-center gap-3 rounded-lg border border-dashed border-border bg-muted/30 py-8">
        <p className="tabular-data text-3xl font-semibold">{formatarTempo(segundos)}</p>

        {!gravando ? (
          <Button type="button" onClick={() => setGravando(true)}>
            <Play className="h-4 w-4" /> {segundos === 0 ? "Iniciar gravação" : "Retomar gravação"}
          </Button>
        ) : (
          <Button type="button" variant="outline" onClick={() => setGravando(false)}>
            <Pause className="h-4 w-4" /> Pausar
          </Button>
        )}

        <p className="max-w-xs text-center text-xs text-muted-foreground">
          A gravação, transcrição automática e geração de SOAP estarão disponíveis em breve.
          Por enquanto, use o campo abaixo para suas anotações.
        </p>
      </div>

      <form className="space-y-4">
        <input type="hidden" name="duracaoSegundos" value={segundos} readOnly />

        <div className="space-y-2">
          <Label htmlFor="observacoes">Observações da consulta</Label>
          <Textarea
            id="observacoes"
            name="observacoes"
            rows={6}
            placeholder="Anote aqui o que for relevante durante o atendimento..."
            defaultValue={observacoesIniciais}
          />
        </div>

        <div className="flex gap-2">
          <Button type="submit" formAction={salvarObservacoesComId} variant="outline">
            Salvar observações
          </Button>
          <Button type="submit" formAction={finalizarComId}>
            <Square className="h-4 w-4" /> Finalizar consulta
          </Button>
        </div>
      </form>
    </div>
  );
}
